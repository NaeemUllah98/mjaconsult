import{j as e}from"./motion-CpciLgVn.js";import{a as o}from"./vendor-84nghTYV.js";import{c as a,a0 as d}from"./index-CsoCrXSa.js";/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=a("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const p=a("Copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]);/**
 * @license lucide-react v0.469.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=a("Landmark",[["line",{x1:"3",x2:"21",y1:"22",y2:"22",key:"j8o0r"}],["line",{x1:"6",x2:"6",y1:"18",y2:"11",key:"10tf0k"}],["line",{x1:"10",x2:"10",y1:"18",y2:"11",key:"54lgf6"}],["line",{x1:"14",x2:"14",y1:"18",y2:"11",key:"380y"}],["line",{x1:"18",x2:"18",y1:"18",y2:"11",key:"1kevvc"}],["polygon",{points:"12 2 20 7 4 7",key:"jkujk7"}]]);function r({flag:s,region:l,account:t}){const[n,c]=o.useState(!1);function x(){var i;(i=navigator.clipboard)==null||i.writeText(t.number).then(()=>{c(!0),setTimeout(()=>c(!1),1500)})}return e.jsxs("div",{className:"rounded-xl border border-surface-muted bg-surface p-4",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"text-lg",children:s}),e.jsx("span",{className:"text-xs font-semibold uppercase tracking-wide text-ink-muted",children:l})]}),e.jsxs("div",{className:"mt-2 space-y-1 text-sm",children:[e.jsxs("p",{className:"flex items-center gap-1.5 font-semibold text-ink",children:[e.jsx(u,{className:"h-4 w-4 text-brand-500"}),t.bank||"—"]}),e.jsxs("p",{className:"text-ink-soft",children:[e.jsx("span",{className:"text-ink-muted",children:"Title:"})," ",t.title||"—"]}),e.jsxs("div",{className:"flex items-center justify-between gap-2",children:[e.jsx("p",{className:"break-all font-mono text-ink",children:t.number||"—"}),t.number&&e.jsx("button",{type:"button",onClick:x,className:d("grid h-8 w-8 shrink-0 place-items-center rounded-lg transition",n?"text-emerald-600":"text-ink-muted hover:bg-surface-muted"),title:"Copy account number",children:n?e.jsx(m,{className:"h-4 w-4"}):e.jsx(p,{className:"h-4 w-4"})})]})]})]})}function f({settings:s}){return e.jsxs("div",{className:"space-y-3",children:[e.jsxs("div",{className:"grid gap-3 sm:grid-cols-2",children:[e.jsx(r,{flag:"🇵🇰",region:"Pakistan",account:s.pkAccount}),e.jsx(r,{flag:"🇦🇪",region:"UAE",account:s.uaeAccount})]}),s.instructions&&e.jsx("p",{className:"text-xs text-ink-muted",children:s.instructions})]})}export{u as L,f as P};
