import{ac as t}from"./index-BAogazUK.js";function e(r,o){return+t(r)>+t(o)}export{e as i};
