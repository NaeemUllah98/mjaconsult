import{V as a}from"./index-BAogazUK.js";function o(t){return a(Date.now(),t)}export{o as s};
